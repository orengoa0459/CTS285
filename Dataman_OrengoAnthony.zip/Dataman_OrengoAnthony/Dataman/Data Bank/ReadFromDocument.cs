﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using DatamanLibrary;

namespace Dataman.Data_Bank
{
    public class ReadFromDocument
    {
        public static void StartDataBankTest(ref string file, string input,ConsoleKeyInfo keyboard,bool problemLoop, ref int setNum, ref string dataSetName)
        {
            Console.Clear();//Clears current screen
            #region Variables
            //Declare and initialize variables
            string convert;
            int question = 1;
            int numOne = 0;
            int numTwo = 0;
            int userAnswer = 0;
            int correctAnswer = 0;
            int score = 0;
            bool loop = false;
            string[] setOne;
            //------------------------------------------------------------
            #endregion

            #region Read File Test 
            using (StreamReader path = new StreamReader(file))
            {
                try
                {
                    
                    Console.WriteLine(StandardMessages.DisplayDataQuestions(ref setNum,ref dataSetName));
                    while(! path.EndOfStream)
                    {
                        convert = path.ReadLine();//Convert path into string 
                        setOne = convert.Split(','); //Split CSV file cells by delimitter
                        numOne = int.Parse(setOne[0]); //Set numOne to subscript 0
                        numTwo = int.Parse(setOne[2]); //Set numTwo to subscript 2
                        correctAnswer = int.Parse(setOne[4]); //Set correct answer to subscript 4

                        if (convert.Contains("+"))
                        {
                            correctAnswer = numOne + numTwo;
                            Console.WriteLine($"Question {question}: {numOne} + {numTwo} = ?");
                            Console.Write("Enter Answer: ");
                            input = Console.ReadLine();

                            if (int.TryParse(input, out userAnswer))
                            {
                                if (userAnswer == correctAnswer)
                                {
                                    score++;
                                }
                                else
                                {

                                }
                            }
                            else
                            {
                                //Console.WriteLine(StandardMessages.DisplayInvalidOption());
                            }
                        }
                        else if (convert.Contains("-"))
                        {
                            correctAnswer = numOne - numTwo;
                            Console.WriteLine($"Question {question}: {numOne} - {numTwo} = ?");
                            Console.Write("Enter Answer: ");
                            input = Console.ReadLine();

                            if (int.TryParse(input, out userAnswer))
                            {
                                if (userAnswer == correctAnswer)
                                {
                                    score++;
                                }
                                else
                                {

                                }
                            }
                            else
                            {
                                //Console.WriteLine(StandardMessages.DisplayInvalidOption());
                            }
                        }
                        else if (convert.Contains("x") || file.Contains("X"))
                        {
                            correctAnswer = numOne * numTwo;
                            Console.WriteLine($"Question {question}: {numOne} X {numTwo} = ?");
                            Console.Write("Enter Answer: ");
                            input = Console.ReadLine();

                            if (int.TryParse(input, out userAnswer))
                            {
                                if (userAnswer == correctAnswer)
                                {
                                    score++;
                                }
                                else
                                {

                                }
                            }
                            else
                            {
                                //Console.WriteLine(StandardMessages.DisplayInvalidOption());
                            }
                        }
                        else if (convert.Contains("/"))
                        {
                            correctAnswer = numOne / numTwo;
                            Console.WriteLine($"Question {question}: {numOne} / {numTwo} = ?");
                            Console.Write("Enter Answer: ");
                            input = Console.ReadLine();

                            if (int.TryParse(input, out userAnswer))
                            {
                                if (userAnswer == correctAnswer)
                                {
                                    score++;
                                }
                                else
                                {

                                }
                            }
                            else
                            {
                                //Console.WriteLine(StandardMessages.DisplayInvalidOption());
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    //Display exception for file read errors
                    Console.WriteLine(e);
                }                   
                //Display total score to user
                Console.WriteLine($"Total Score: {score}\n\nPress Enter....");
                Console.ReadLine();
            }
            #endregion
        }

        #region VOID 
        //public static void StartDataBankTestTwo(ref string file, string input, ConsoleKeyInfo keyboard, bool problemLoop)
        //{
        //    Console.Clear();//Clears current screen
        //    #region Variables
        //    //Declare and initialize variables
        //    string convert;
        //    int question = 1;
        //    int numOne = 0;
        //    int numTwo = 0;
        //    int userAnswer = 0;
        //    int correctAnswer = 0;
        //    int score = 0;
        //    bool loop = false;
        //    string[] setOne;
        //    //------------------------------------------------------------
        //    #endregion

        //    #region Read File Test Two
        //    using (StreamReader path = new StreamReader(file))
        //    {
        //        try
        //        {
        //            int num = 1;
        //            Console.WriteLine(StandardMessages.DisplayDataQuestions(ref num));
        //            while (!path.EndOfStream)
        //            {
        //                convert = path.ReadLine();//Convert path into string 
        //                setOne = convert.Split(','); //Split CSV file cells by delimitter
        //                numOne = int.Parse(setOne[0]); //Set numOne to subscript 0
        //                numTwo = int.Parse(setOne[2]); //Set numTwo to subscript 2
        //                correctAnswer = int.Parse(setOne[4]); //Set correct answer to subscript 4

        //                if (convert.Contains("+"))
        //                {
        //                    correctAnswer = numOne + numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} + {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("-"))
        //                {
        //                    correctAnswer = numOne - numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} - {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("x") || file.Contains("X"))
        //                {
        //                    correctAnswer = numOne * numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} X {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("/"))
        //                {
        //                    correctAnswer = numOne / numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} / {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            //Display exception for file read errors
        //            Console.WriteLine(e);
        //        }
        //        //Display total score to user
        //        Console.WriteLine($"Total Score: {score}\n\nPress Enter....");
        //        Console.ReadLine();
        //    }
        //    #endregion
        //}
        //public static void StartDataBankTestThree(ref string file, string input, ConsoleKeyInfo keyboard, bool problemLoop)
        //{
        //    Console.Clear();//Clears current screen
        //    #region Variables
        //    //Declare and initialize variables
        //    string convert;
        //    int question = 1;
        //    int numOne = 0;
        //    int numTwo = 0;
        //    int userAnswer = 0;
        //    int correctAnswer = 0;
        //    int score = 0;
        //    bool loop = false;
        //    string[] setOne;
        //    //------------------------------------------------------------
        //    #endregion

        //    #region Read File Test Three
        //    using (StreamReader path = new StreamReader(file))
        //    {
        //        try
        //        {
        //            int num = 1;
        //            Console.WriteLine(StandardMessages.DisplayDataQuestions(ref num));
        //            while (!path.EndOfStream)
        //            {
        //                convert = path.ReadLine();//Convert path into string 
        //                setOne = convert.Split(','); //Split CSV file cells by delimitter
        //                numOne = int.Parse(setOne[0]); //Set numOne to subscript 0
        //                numTwo = int.Parse(setOne[2]); //Set numTwo to subscript 2
        //                correctAnswer = int.Parse(setOne[4]); //Set correct answer to subscript 4

        //                if (convert.Contains("+"))
        //                {
        //                    correctAnswer = numOne + numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} + {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("-"))
        //                {
        //                    correctAnswer = numOne - numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} - {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("x") || file.Contains("X"))
        //                {
        //                    correctAnswer = numOne * numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} X {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("/"))
        //                {
        //                    correctAnswer = numOne / numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} / {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            //Display exception for file read errors
        //            Console.WriteLine(e);
        //        }
        //        //Display total score to user
        //        Console.WriteLine($"Total Score: {score}\n\nPress Enter....");
        //        Console.ReadLine();
        //    }
        //    #endregion

        //}
        //public static void StartDataBankTestFour(ref string file, string input, ConsoleKeyInfo keyboard, bool problemLoop)
        //{
        //    Console.Clear();//Clears current screen
        //    #region Variables
        //    //Declare and initialize variables
        //    string convert;
        //    int question = 1;
        //    int numOne = 0;
        //    int numTwo = 0;
        //    int userAnswer = 0;
        //    int correctAnswer = 0;
        //    int score = 0;
        //    bool loop = false;
        //    string[] setOne;
        //    //------------------------------------------------------------
        //    #endregion

        //    #region Read File Test Four
        //    using (StreamReader path = new StreamReader(file))
        //    {
        //        try
        //        {
        //            int num = 1;
        //            Console.WriteLine(StandardMessages.DisplayDataQuestions(ref num));
        //            while (!path.EndOfStream)
        //            {
        //                convert = path.ReadLine();//Convert path into string 
        //                setOne = convert.Split(','); //Split CSV file cells by delimitter
        //                numOne = int.Parse(setOne[0]); //Set numOne to subscript 0
        //                numTwo = int.Parse(setOne[2]); //Set numTwo to subscript 2
        //                correctAnswer = int.Parse(setOne[4]); //Set correct answer to subscript 4

        //                if (convert.Contains("+"))
        //                {
        //                    correctAnswer = numOne + numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} + {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("-"))
        //                {
        //                    correctAnswer = numOne - numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} - {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("x") || file.Contains("X"))
        //                {
        //                    correctAnswer = numOne * numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} X {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("/"))
        //                {
        //                    correctAnswer = numOne / numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} / {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            //Display exception for file read errors
        //            Console.WriteLine(e);
        //        }
        //        //Display total score to user
        //        Console.WriteLine($"Total Score: {score}\n\nPress Enter....");
        //        Console.ReadLine();
        //    }
        //    #endregion

        //}
        //public static void StartDataBankTestFive(ref string file, string input, ConsoleKeyInfo keyboard, bool problemLoop)
        //{
        //    Console.Clear();//Clears current screen
        //    #region Variables
        //    //Declare and initialize variables
        //    string convert;
        //    int question = 1;
        //    int numOne = 0;
        //    int numTwo = 0;
        //    int userAnswer = 0;
        //    int correctAnswer = 0;
        //    int score = 0;
        //    bool loop = false;
        //    string[] setOne;
        //    //------------------------------------------------------------
        //    #endregion

        //    #region Read File Test Five
        //    using (StreamReader path = new StreamReader(file))
        //    {
        //        try
        //        {
        //            int num = 1;
        //            Console.WriteLine(StandardMessages.DisplayDataQuestions(ref num));
        //            while (!path.EndOfStream)
        //            {
        //                convert = path.ReadLine();//Convert path into string 
        //                setOne = convert.Split(','); //Split CSV file cells by delimitter
        //                numOne = int.Parse(setOne[0]); //Set numOne to subscript 0
        //                numTwo = int.Parse(setOne[2]); //Set numTwo to subscript 2
        //                correctAnswer = int.Parse(setOne[4]); //Set correct answer to subscript 4

        //                if (convert.Contains("+"))
        //                {
        //                    correctAnswer = numOne + numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} + {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("-"))
        //                {
        //                    correctAnswer = numOne - numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} - {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("x") || file.Contains("X"))
        //                {
        //                    correctAnswer = numOne * numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} X {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //                else if (convert.Contains("/"))
        //                {
        //                    correctAnswer = numOne / numTwo;
        //                    Console.WriteLine($"Question {question}: {numOne} / {numTwo} = ?");
        //                    Console.Write("Enter Answer: ");
        //                    input = Console.ReadLine();

        //                    if (int.TryParse(input, out userAnswer))
        //                    {
        //                        if (userAnswer == correctAnswer)
        //                        {
        //                            score++;
        //                        }
        //                        else
        //                        {

        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Console.WriteLine(StandardMessages.DisplayInvalidOption());
        //                    }
        //                }
        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            //Display exception for file read errors
        //            Console.WriteLine(e);
        //        }
        //        //Display total score to user
        //        Console.WriteLine($"Total Score: {score}\n\nPress Enter....");
        //        Console.ReadLine();
        //    }
        //    #endregion

        //}

        #endregion
    }
}
