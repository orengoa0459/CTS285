﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatamanLibrary;
namespace Dataman
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Variables and objects
            bool menuLoop = false;
            Player player = new Player();
            int countProblems = 0;
            int answerCheckerScore = 0;
            int electroFlashScore = 0;
            int numberGuesserScore = 0;
            ConsoleKeyInfo keyboard = new ConsoleKeyInfo();
            #endregion

            #region Main Menu Dataman
            do
            {
                Console.Clear();
                //Display main menu to the user
                Console.WriteLine(StandardMessages.DataMainMenu());
                //Get keyboard input from user
                keyboard = Console.ReadKey();
                //Control flow of the main menu
                switch (keyboard.Key)
                {
                    //Answer Checker Option
                    case ConsoleKey.D1:
                    case ConsoleKey.NumPad1:
                        AnswerChecker.CheckUsersAnswer(ref player, ref answerCheckerScore,ref countProblems);
                        break;
                    //Electro Flash option
                    case ConsoleKey.D2:
                    case ConsoleKey.NumPad2:
                        ElectroFlashMain.ElectroFlashMenu(ref player, ref electroFlashScore);
                        break;
                    //Number Guesser option
                    case ConsoleKey.D3:
                    case ConsoleKey.NumPad3:
                        NumberGuesser.NumberGuesser.GuessDatamansNumber(ref player, ref numberGuesserScore);
                        break;
                    case ConsoleKey.D4:
                    case ConsoleKey.NumPad4:
                        
                        break;
                    case ConsoleKey.D5:
                    case ConsoleKey.NumPad5:
                        
                        break;
                        //Data Bank Option
                    case ConsoleKey.D6:
                    case ConsoleKey.NumPad6:
                        Data_Bank.DataBankDocument.DataBankMenu();
                        break;
                    //Display total scores for all games
                    case ConsoleKey.D7:
                    case ConsoleKey.NumPad7:
                        Console.Clear();
                        Console.WriteLine(StandardMessages.TotalScores(ref countProblems, ref answerCheckerScore, ref electroFlashScore));
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    //Ends program
                    case ConsoleKey.Escape:                    
                        menuLoop = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.DisplayInvalidOption());
                        break;
                }
            } while (menuLoop == false);
            #endregion
        }
    }
}
