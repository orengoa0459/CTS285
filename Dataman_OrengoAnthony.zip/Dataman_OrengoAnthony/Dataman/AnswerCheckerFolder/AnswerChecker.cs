﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatamanLibrary;
using System.Text.RegularExpressions;
namespace Dataman
{
    public class AnswerChecker
    {
        public static void CheckUsersAnswer(ref Player player, ref int answerCheckerScore, ref int countProblems)
        {
            #region Answer Checker
            Console.Clear();
            #region Variables
            int number1 = 0;
            int number2 = 0;
            int userAnswer = 0;
            int correctAnswer = 0;
            string arithOperator = "";
            string mathProblem;            
            string input;
            int tryCounter = 0;
            bool inputLoop = false;
            bool answerCheckLoop = false;
            #endregion

            #region Input Problem
            try
            {
                do
                {
                    //Display title to user-------------------------
                    Console.WriteLine(StandardMessages.AnswerCheckerTitle());
                    //Get input from user---------------------------
                    Console.Write("Enter math problem: ");
                    mathProblem = Console.ReadLine();
                    //Removes all the whitespace in string-----------------
                    mathProblem = mathProblem.Replace(" ", String.Empty);

                    //Tokenize users string -------------------------------------
                    string[] tokens = mathProblem.Split('+', '-', 'x','X','*', '/', '=');

                    //Parse string of tokens to integers----------------------------------------------------------------
                    if (int.TryParse(tokens[0], out number1))
                    {
                        if (int.TryParse(tokens[1], out number2))
                        {
                            //Determine if numbers are larger than 2 digits
                            if (number1 > 100 || number2 > 100)
                            {
                                Console.WriteLine("\nInvalid Entry!\nNumbers cannot exceed two digits.\n\nEx: 99+99=198\nPress Enter...");
                                Console.ReadLine();
                                Console.Clear();
                            }
                            else if (int.TryParse(tokens[2], out userAnswer))
                            {
                                inputLoop = true;
                            }
                            else
                            {
                                Console.WriteLine("Invalid Entry!\n Example 1+2=3\n\nPress Enter...");
                            }
                           
                        }
                        else
                        {
                            Console.WriteLine("Invalid Entry!\nExample 1+2=3\n\nPress Enter...");
                        }
                        
                    }
                    else
                    {
                        Console.WriteLine("Invalid Entry!\nExample 1+2=3\n\nPress Enter...");
                    }
                    
                } while (inputLoop == false);
                
                #endregion End Input Problem

            #region Math Problem Checker

                #region Addition Checker
                if (mathProblem.Contains("+"))
                {
                    countProblems++;
                    do
                    {
                        //Count number of tries
                        tryCounter++;
                        if (userAnswer == Calculator.CheckAddition(number1, number2, correctAnswer))
                        {
                            Console.WriteLine("Great Job!\n\nPress Enter...");
                            tryCounter = 0;
                            answerCheckLoop = true;
                            answerCheckerScore++;
                        }
                        else
                        {
                            if (tryCounter == 2)
                            {
                                Console.WriteLine("You exceeded number of tries!\n" +
                                    "The correct answer is " + Calculator.CheckAddition(number1, number2, correctAnswer) + "\n\nPress Enter...");
                                tryCounter = 0;
                                answerCheckLoop = true;
                            }
                            else if (tryCounter < 2)
                            {
                                Console.WriteLine("\nYour answer is incorrect!\n");
                                Console.Write($"Try again!\nProblem: {number1} + {number2} = ");
                                input = Console.ReadLine();
                                if (int.TryParse(input, out userAnswer))
                                {
                                    if (userAnswer != correctAnswer)
                                    {

                                    }
                                    else
                                    {
                                        Console.WriteLine("Great Job!\n\nPress Enter...");
                                        tryCounter = 0;
                                        answerCheckLoop = true;
                                        answerCheckerScore++;
                                    }
                                }
                            }
                        }

                    } while (answerCheckLoop == false);

                }
                #endregion

                #region Subtraction Checker
                else if (mathProblem.Contains("-"))
                {
                    countProblems++;
                    tryCounter++;
                        if (number1 < number2)
                        {
                            Console.WriteLine("Invalid entry! Negative number!");
                        }
                        else
                        {
                            if (userAnswer == Calculator.CheckSubtraction(number1, number2, correctAnswer))
                            {
                                Console.WriteLine("Great Job!");
                                tryCounter = 0;
                                answerCheckerScore++;
                                answerCheckLoop = true;
                            }
                            else
                            {
                                if (tryCounter == 2)
                                {
                                    Console.WriteLine("You exceeded number of tries!\n" +
                                        "The correct answer is " + Calculator.CheckSubtraction(number1, number2, correctAnswer) + "\n\nPress Enter...");
                                    tryCounter = 0;
                                    answerCheckLoop = true;
                                }
                                else if (tryCounter < 2)
                                {
                                    Console.WriteLine("\nYour answer is incorrect!\n");
                                    Console.Write($"Try again!\nProblem: {number1} - {number2} = ");
                                    input = Console.ReadLine();
                                    if (int.TryParse(input, out userAnswer))
                                    {
                                        if (userAnswer != correctAnswer)
                                        {

                                        }
                                        else
                                        {
                                            Console.WriteLine("Great Job!\n\nPress Enter...");
                                            tryCounter = 0;
                                            answerCheckLoop = true;
                                            answerCheckerScore++;
                                        }
                                    }
                                }
                            }
                        }
                   
                }
                #endregion

                #region Multiplication Checker
                else if (mathProblem.Contains("*") || mathProblem.Contains("x") || mathProblem.Contains("X"))
                {
                    countProblems++;
                    do
                    {
                        tryCounter++;
                        if (userAnswer == Calculator.CheckMultiplication(number1, number2, correctAnswer))
                        {
                            Console.WriteLine("Great Job!");
                            tryCounter = 0;
                            answerCheckerScore++;
                            answerCheckLoop = true;
                        }
                        else
                        {
                            if (tryCounter == 2)
                            {
                                Console.WriteLine("You exceeded number of tries!\n" +
                                    "The correct answer is " + Calculator.CheckMultiplication(number1, number2, correctAnswer) + "\n\nPress Enter...");
                                tryCounter = 0;
                                answerCheckLoop = true;
                            }
                            else if (tryCounter < 2)
                            {
                                Console.WriteLine("\nYour answer is incorrect!\n");
                                Console.Write($"Try again!\nProblem: {number1} * {number2} = ");
                                input = Console.ReadLine();
                                if (int.TryParse(input, out userAnswer))
                                {
                                    if (userAnswer != correctAnswer)
                                    {

                                    }
                                    else
                                    {
                                        Console.WriteLine("Great Job!\n\nPress Enter...");
                                        tryCounter = 0;
                                        answerCheckLoop = true;
                                        answerCheckerScore++;
                                    }
                                }
                            }
                        }
                    } while (answerCheckLoop == false);
                 }                   
                #endregion

                #region Division Checker
                else if (mathProblem.Contains("/"))
                {
                    countProblems++;
                    do
                    {
                        tryCounter++;
                        if (userAnswer == Calculator.CheckDivision(number1, number2, correctAnswer))
                        {
                            Console.WriteLine("Great Job!");
                            answerCheckerScore++;
                            tryCounter = 0;
                            answerCheckLoop = true;
                        }
                        else
                        {
                            if (tryCounter == 2)
                            {
                                Console.WriteLine("You exceeded number of tries!\n" +
                                    "The correct answer is " + Calculator.CheckDivision(number1, number2, correctAnswer) + "\n\nPress Enter...");
                                tryCounter = 0;
                                answerCheckLoop = true;
                            }
                            else if (tryCounter < 2)
                            {
                                Console.WriteLine("\nYour answer is incorrect!\n");
                                Console.Write($"Try again!\nProblem: {number1} / {number2} = ");
                                input = Console.ReadLine();
                                if (int.TryParse(input, out userAnswer))
                                {
                                    if (userAnswer != correctAnswer)
                                    {

                                    }
                                    else
                                    {
                                        Console.WriteLine("Great Job!\n\nPress Enter...");
                                        tryCounter = 0;
                                        answerCheckLoop = true;
                                        answerCheckerScore++;
                                    }
                                }
                            }
                        }
                    } while (answerCheckLoop == false);
                }                                 
                #endregion
            }
            catch (IndexOutOfRangeException) 
            {
                Console.WriteLine("Invalid Entry!\nExample 1+2=3\n\nPress Enter...");
                Console.ReadLine();
                Console.Clear();
            }
            Console.ReadLine();
            Console.Clear();
            #endregion

        }
        #endregion Answer Checker
    }
}
