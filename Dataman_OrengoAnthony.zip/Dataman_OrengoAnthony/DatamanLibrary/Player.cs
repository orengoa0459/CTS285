﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatamanLibrary
{
    public class Player
    {
        //Fields
        private string _name;
        private int _score;

        //Default constructors
        public Player()
        {
            Name = "";
            Score = 0;
        }

        //Custom Constructors
        public Player(string name, int score)
        {
            Name = name;
            Score = score;
        }

        //Properties

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public int Score
        {
            get
            {
                return _score;
            }
            set
            {
                _score = value;
            }
        }
    }
}
