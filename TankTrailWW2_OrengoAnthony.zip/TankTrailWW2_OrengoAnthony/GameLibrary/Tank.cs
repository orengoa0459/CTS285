﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class Tank
    {
        private string _tankName;
        private string _tankCountry;
        private string _tankTierLevel;
        private string _tankDescription;
        private int _tankHealth;
        private int _tankArmor;
        private int _strikePower;

        public Tank()
        {
            TankName = "";
            TankCountry = "";
            TankTierLevel = "";
            TankDescription = "";
            TankHealth = 0;
            TankArmor = 0;
            StrikePower = 0;


        }
        public Tank(string tankName,string tankCountry, string tankTierLevel, string tankDescription, int tankHealth, int tankArmor, int strikePower)
        {
            TankName = tankName;
            TankCountry = tankCountry;
            TankTierLevel = tankTierLevel;
            TankDescription = tankDescription;
            TankHealth = tankHealth;
            TankArmor = tankArmor;
            StrikePower = strikePower;


        }

        public string TankName
        {
            get
            {
                return _tankName;
            }
            set
            {
                _tankName = value;
            }
        }
        public string TankCountry
        {
            get
            {
                return _tankCountry;
            }
            set
            {
                _tankCountry = value;
            }
        }
        public string TankTierLevel
        {
            get
            {
                return _tankTierLevel;
            }
            set
            {
                _tankTierLevel = value;
            }
        }
        public string TankDescription
        {
            get
            {
                return _tankDescription;
            }
            set
            {
                _tankDescription = value;
            }
        }
        public int TankHealth
        {
            get
            {
                return _tankHealth;
            }
            set
            {
                _tankHealth = value;
            }
        }
        public int TankArmor
        {
            get
            {
                return _tankArmor;
            }
            set
            {
                _tankArmor = value;
            }
        }
        public int StrikePower
        {
            get
            {
                return _strikePower;
            }
            set
            {
                _strikePower = value;
            }
        }
    }
}
