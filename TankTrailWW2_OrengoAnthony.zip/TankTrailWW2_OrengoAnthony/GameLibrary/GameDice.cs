﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class GameDice
    {
        private int _diceOne;
        private int _diceTwo;    


        public GameDice()
        {
            DiceOne = 0;
            DiceTwo = 0;
           


        }
        public GameDice(int diceOne, int diceTwo)
        {
            DiceOne = diceOne;
            DiceTwo = diceTwo;
          



        }

        public int DiceOne
        {
            get
            {
                return _diceOne;

            }
            set
            {
                _diceOne = value;
            }
        }
        public int DiceTwo
        {
            get
            {
                return _diceTwo;

            }
            set
            {
                _diceTwo = value;
            }
        }
    }
}
