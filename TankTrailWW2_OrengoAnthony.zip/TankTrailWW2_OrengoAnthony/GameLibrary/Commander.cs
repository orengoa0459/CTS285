﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    public class Commander
    {
        private string _commanderName;
        private string _commanderRankLevel;
        private string _commanderDescription;
        private int _diceNumber;
        
        public Commander()
        {
            CommanderName = "";
            CommanderRankLevel = "";
            CommanderDescription = "";
            DiceNumber = 0;
        }

        public Commander(string commanderName, string commanderRankLevel, string commanderDescription, int diceNumber)
        {
            CommanderName = commanderName;
            CommanderRankLevel = commanderRankLevel;
            CommanderDescription = commanderDescription;
            DiceNumber = DiceNumber;
        }

        public string CommanderName
        {
            get
            {
                return _commanderName;
            }
            set
            {
                _commanderName = value;
            }
        }
        public string CommanderRankLevel
        {
            get
            {
                return _commanderRankLevel;
            }
            set
            {
                _commanderRankLevel = value;
            }
        }
        public string CommanderDescription
        {
            get
            {
                return _commanderDescription;
            }
            set
            {
                _commanderDescription = value;
            }
        }
        public int DiceNumber
        {
            get
            {
                return _diceNumber;
            }
            set
            {
                _diceNumber = value;
            }
        }


    }
}
