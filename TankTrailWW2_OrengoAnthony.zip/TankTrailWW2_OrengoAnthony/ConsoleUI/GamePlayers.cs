﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameLibrary;
namespace ConsoleUI
{
    public class GamePlayers
    {
        public static void GenerateGameCharacters(ref List<Commander> players, ref int num, ref Commander player)
        {
            for(int i = 0; i < num; i++)
            {
                players.Add(new Commander (player.CommanderName,player.CommanderRankLevel,player.CommanderDescription,player.DiceNumber));
            }            
        }
    }
}
