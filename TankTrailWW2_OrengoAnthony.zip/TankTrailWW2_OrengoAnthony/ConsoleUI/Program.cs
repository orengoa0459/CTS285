﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using GameLibrary;
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create dice object 
            GameDice dice = new GameDice();
            //Declare and initialize main menu loop sentinel
            bool mainMenuLoop = false;
            //Create keyboard object to get input from user
            ConsoleKeyInfo keyboard = new ConsoleKeyInfo();
            string input;
            //Determine directory path for document files
            string directory = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            do
            {
                //Displays main menu
                DisplayGameDocuments.DisplayMainMenu(directory);
                //Get input from user
                keyboard = Console.ReadKey();
                //Controls flow of main menu
                switch (keyboard.Key)
                {
                    case ConsoleKey.D1:
                    case ConsoleKey.NumPad1:
                        //Starts Tank Trail WWII game
                        StartTankTrailGame.PlayerAndTankSlection(directory,keyboard,dice);
                        break;
                    case ConsoleKey.D2:
                    case ConsoleKey.NumPad2:

                        break;
                    case ConsoleKey.D3:
                    case ConsoleKey.NumPad3:

                        break;
                    case ConsoleKey.Escape:
                        //Ends program
                        mainMenuLoop = true;
                        break;
                    default:
                        //Displays invalid option to user
                        Console.WriteLine(GameLibrary.StandardMessages.DisplayInvalidSelection());
                        break;
                }
                Console.Clear();
            } while (mainMenuLoop == false);
        }
    }
}
