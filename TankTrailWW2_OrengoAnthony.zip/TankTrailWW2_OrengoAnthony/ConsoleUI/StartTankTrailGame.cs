﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using GameLibrary;
namespace ConsoleUI
{
    public class StartTankTrailGame
    {
        public static void PlayerAndTankSlection(string directory, ConsoleKeyInfo keyboard, GameDice dice)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            bool menuLoop = false;
            int num = 0;
            //Create player object
            Commander player = new Commander();
            List<Commander> players = new List<Commander>();
            do
            {   
                //Display player and tank selection menu
                DisplayGameDocuments.DisplayPlayerAndTankeSelectionMenu(directory);
                keyboard = Console.ReadKey();

                switch (keyboard.Key)
                {
                    case ConsoleKey.D1:
                    case ConsoleKey.NumPad1:
                        SelectNumberOfPlayers(keyboard, menuLoop,directory,ref num);
                        GamePlayers.GenerateGameCharacters(ref players,ref num, ref player);
                        break;
                    case ConsoleKey.D2:
                    case ConsoleKey.NumPad2:
                        BattleCountry.GetPlayerBattleCountry(ref players, directory,dice);
                        break;
                    case ConsoleKey.D3:
                    case ConsoleKey.NumPad3:

                        break;
                    case ConsoleKey.Escape:
                        menuLoop = true;
                        break;
                    default:
                        Console.WriteLine(GameLibrary.StandardMessages.DisplayInvalidSelection());
                        break;
                }
                //Console.ReadLine();

            } while (menuLoop == false);
            Console.ForegroundColor = ConsoleColor.White;
        }
        public static void SelectNumberOfPlayers(ConsoleKeyInfo keyboard,bool loop, string directory,ref int num)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
            num = 0;
            //Get number of players from user
            do
            {
                DisplayGameDocuments.SelectTotalPlayers(directory);
                keyboard = Console.ReadKey();

                switch (keyboard.Key)
                {
                    case ConsoleKey.D1:
                    case ConsoleKey.NumPad1:
                        num = 2;
                        loop = true;
                        break;
                    case ConsoleKey.D2:
                    case ConsoleKey.NumPad2:
                        num = 3;
                        loop = true;
                        break;
                    case ConsoleKey.D3:
                    case ConsoleKey.NumPad3:
                        num = 4;
                        loop = true;
                        break;
                    case ConsoleKey.D4:
                    case ConsoleKey.NumPad4:
                        num = 5;
                        loop = true;
                        break;
                    case ConsoleKey.D5:
                    case ConsoleKey.NumPad5:
                        num = 6;
                        loop = true;
                        break;
                    case ConsoleKey.Escape:
                        loop = true;
                        break;
                    default:
                        Console.WriteLine(GameLibrary.StandardMessages.DisplayInvalidSelection());
                        break;
                }
                //Console.ReadLine();

            } while (loop == false);
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
        }
    }
    
}
