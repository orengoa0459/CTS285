﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameLibrary;
namespace ConsoleUI
{
    public class BattleCountry
    {
        public static void GetPlayerBattleCountry(ref List<Commander> players, string directory, GameDice dice)
        {
            Console.Clear();
            string diceImageOne = "";
            bool loop = false;         
            //Battle Country Instructions----------------------------------------------------------------------
            DisplayGameDocuments.DisplayBattleCountryInstructions(directory);
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Roll to choose your battle country.");
                
            //RollDice.DetermineWhoRollsFirst(ref dice);
            //Roll to Choose Battle Country---------------------------------------------------------------------

            
            //Determine who won the roll-----------------------------------------------------------------------------
            do
            {
                int num = 0;
                int playerNumIdentifier = 1;
                for (int i = 0; i < players.Count; i++)
                {
                    Console.WriteLine($"Player{playerNumIdentifier}: Press enter to roll your dice.");
                    Console.ReadLine();
                    RollDice.RollOneGameDice(ref dice);
                    players[i].DiceNumber = dice.DiceOne;
                    Console.WriteLine("Player" + playerNumIdentifier + "'s roll:");
                    DisplayDiceImage.ShowDiceImageOne(ref dice, ref diceImageOne);
                    Console.ReadLine();
                    playerNumIdentifier++;
                }
                if (players[0].DiceNumber > players[1].DiceNumber)
                {
                    Console.WriteLine("Player one wins ");
                    loop = true;
                }
                else if (players[1].DiceNumber > players[0].DiceNumber)
                {
                    Console.WriteLine("Player two wins");
                    loop = true;
                }
                else if (players[1].DiceNumber == players[0].DiceNumber || players[0].DiceNumber == players[1].DiceNumber)
                {
                    
                }
                else
                {
                    Console.WriteLine("Invalid! Error!");
                }
                Console.ReadLine();


            } while (loop == false);
            
            //=======================================================================================
            Console.ForegroundColor = ConsoleColor.White;


            //TODO Create Battle Country Selection menu 
            //TODO remove country from selection menu when a player chooses it
            //TODO Add battle country to players stats
            //
        }
    }
}
