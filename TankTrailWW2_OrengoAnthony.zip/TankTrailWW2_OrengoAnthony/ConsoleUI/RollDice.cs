﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameLibrary;
namespace ConsoleUI
{
    public class RollDice
    {
        public static void RollOneGameDice( ref GameDice dice)
        {
            //Declare and initialize for loop variable
            int num = 0; 
            //Create random object
            Random rand = new Random();
            //Determines how many times the loop will itterate to simulate a more random number
            num = rand.Next(1, 50);
            for(int i = 0; i < num; i++)
            {
                //Gets random number 1-6
                dice.DiceOne = rand.Next(1, 7);
            }           
        }
        public static void DetermineWhoRollsFirst(ref GameDice dice)
        {
            int num = 0;

            Random rand = new Random();
            num = rand.Next(1, 50);
            for (int i = 0; i < num; i++)
            {
                dice.DiceOne = rand.Next(1, 7);
            }


        }
    }
}
